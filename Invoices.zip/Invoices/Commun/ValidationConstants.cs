﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Invoices.Commun
{
    public static  class ValidationConstants
    {
        //Product 

        //•	Name – text with length[9…30] (required)
        //•	Price – decimal in range[5.00…1000.00] (required)
        //•	CategoryType – enumeration of type CategoryType, with possible values(ADR, Filters, Lights, Others, Tyres) (required)

        public const int MinLenghProductName = 9;
        public const int MaxProductLenghtName = 30;
        public const string MinPrice = "5.00";
        public const string MaxPrice = "1000.00";
        public const int MinCategoryType = 0;
        public const int MaxCategoryType =4 ;   


        //Address

        //•	StreetName – text with length[10…20] (required)
        //•	City – text with length[5…15] (required)
        //•	Country – text with length[5…15] (required)
        public const int MinLenghtAddress = 10;
        public const int MaxLenghtAddress = 20;
        public const int MinLenghtCity = 5;
        public const int MaxLenghtCity = 15;
        public const int MinLenghtCountry = 5;
        public const int MaxLenghtCountry = 15;

        //Invoice 
        //•	Number – integer in range[1, 000, 000, 000…1, 500, 000, 000] (required)
        //•	CurrencyType – enumeration of type CurrencyType, with possible values(BGN, EUR, USD) (required)
        public const int MinNumberInvoice= 1000000000;
        public const int MaxNumberInvoice = 1500000000;
        public const int MinCurrencyType = 0;
        public const int MaxCurrencyType = 2;


        //Client
        //Name – text with length[10…25] (required)
        //NumberVat – text with length[10…15] (required)

        public const int MinLeghtClientName = 10;
        public const int MaxLenghtClientName = 25;
        public const int MinLenghtNumberVat = 10;
        public const int MaxLenghtNumberVat = 15;


    }
}
