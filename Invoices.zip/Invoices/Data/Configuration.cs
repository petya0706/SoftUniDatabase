﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=LAPTOP-1RVRTVEV\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
