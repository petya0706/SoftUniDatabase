﻿


namespace Invoices.Data.Models
{
    using System.ComponentModel.DataAnnotations;
    public  class Client
    {
		//    Id – integer, Primary Key
		//Name – text with length[10…25] (required)
		//NumberVat – text with length[10…15] (required)
		//Invoices – collection of type Invoicе
		//Addresses – collection of type Address
		//ProductsClients – collection of type ProductClient
		public Client() 
		{
			this.Invoices = new HashSet<Invoice>();
			this.Addresses = new HashSet<Address>();
			this.ProductsClients = new HashSet<ProductClient>();	
		}

		[Key]
		public int Id { get; set; }

		[Required]
		public string Name { get; set; } = null!;

		[Required]
		public string NumberVat { get; set; } = null!;

		public virtual ICollection<Invoice> Invoices { get; set; }

		public virtual ICollection<Address> Addresses { get; set; }

		public virtual ICollection<ProductClient> ProductsClients { get; set; }

    }
}
