﻿


namespace Invoices.Data.Models
{
    using System.ComponentModel.DataAnnotations;

    using Enums;

    public  class Product
    {
        //        •	Id – integer, Primary Key
        //•	Name – text with length[9…30] (required)
        //•	Price – decimal in range[5.00…1000.00] (required)
        //•	CategoryType – enumeration of type CategoryType, with possible values(ADR, Filters, Lights, Others, Tyres) (required)
        //•	ProductsClients – collection of type ProductClient
        public Product()
        { 
            this.ProductsClients=new HashSet<ProductClient>();
        }

        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        public decimal Price { get; set; }

        public CategoryType CategoryType { get; set; }

        //•	ProductsClients – collection of type ProductClient
        public virtual ICollection<ProductClient> ProductsClients { get; set; }


    }
}
