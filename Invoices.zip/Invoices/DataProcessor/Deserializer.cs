﻿namespace Invoices.DataProcessor
{
    using System.ComponentModel.DataAnnotations;
    using Invoices.Data;
    using Data.Models;
    using Invoices.DataProcessor.ImportDto;
    using Utilities;
    using System.Text;
    using AutoMapper;
    using Newtonsoft.Json;
    using System.Globalization;
    using Invoices.Data.Models.Enums;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedClients
            = "Successfully imported client {0}.";

        private const string SuccessfullyImportedInvoices
            = "Successfully imported invoice with number {0}.";

        private const string SuccessfullyImportedProducts
            = "Successfully imported product - {0} with {1} clients.";


        public static string ImportClients(InvoicesContext context, string xmlString)
        {
            XmlHelper xmlHelper = new XmlHelper();
            var clientsDto = xmlHelper.Deserialize<ImportClientDTO[]>(xmlString, "Clients");
            StringBuilder sb = new StringBuilder();

            var mappedClients = new HashSet<Client>();
            foreach (var clientDto in clientsDto)
            {
                if (!IsValid(clientDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                Client client = new Client()
                {
                    Name = clientDto.Name,
                    NumberVat = clientDto.NumberVat
                };
                MapperConfig mapconfig = new MapperConfig();
                IMapper mapper = mapconfig.ConfigurationMapper();
               
                foreach(var adressDto in clientDto.Addresses)
                {
                    if (!IsValid(adressDto))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }
                    Address address=mapper.Map<Address>(adressDto);
                    client.Addresses.Add(address);
                   
                }
              mappedClients.Add(client);
                sb.AppendLine(string.Format(SuccessfullyImportedClients, client.Name));
            }
            context.Clients.AddRange(mappedClients);
            context.SaveChanges();
            return sb.ToString().TrimEnd();
        }


        public static string ImportInvoices(InvoicesContext context, string jsonString)
        {
            var invoicesDto = JsonConvert.DeserializeObject<ImportInvoiceDto[]>(jsonString);
            var mappedInvoices = new HashSet<Invoice>();
            StringBuilder sb = new StringBuilder();

            foreach(var invoiceDto in invoicesDto)
            {
                if (!IsValid(invoiceDto) || invoiceDto.Amount<0)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;   
                }

                DateTime issueDate;
                bool isValidIssueDate = DateTime.TryParse(invoiceDto.IssueDate, CultureInfo.InvariantCulture, 
                    DateTimeStyles.None, out issueDate);

                DateTime duedate;
                bool isValidDueDate = DateTime.TryParse(invoiceDto.Duedate, CultureInfo.InvariantCulture, 
                    DateTimeStyles.None, out duedate);

                if(duedate<issueDate)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                if(!context.Clients.Select(c =>c.Id).Contains(invoiceDto.ClientId))
                {
                    sb.AppendLine(ErrorMessage);
                }
                MapperConfig mapConfig = new MapperConfig();
                IMapper mapper = mapConfig.ConfigurationMapper();
                Invoice invoice = mapper.Map<Invoice>(invoiceDto);
                mappedInvoices.Add(invoice);
                sb.AppendLine(string.Format(SuccessfullyImportedInvoices, invoice.Number));
            }
            context.Invoices.AddRange(mappedInvoices);
            context.SaveChanges();
            return sb.ToString().TrimEnd();
        }

        public static string ImportProducts(InvoicesContext context, string jsonString)
        {
            var productsDto = JsonConvert.DeserializeObject<ImportProductDto[]>(jsonString);
            var mappedProducts = new HashSet<Product>();
            StringBuilder sb =new StringBuilder();

            foreach(var productDto in productsDto)
            {
                if (!IsValid(productDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                Product product = new Product()
                {
                    Name = productDto.Name,
                    Price = productDto.Price,
                    CategoryType = (CategoryType)productDto.CategoryType,

                };
                var existingClients = context.Clients.Select(c => c.Id).ToArray();
                
                foreach(var clientId  in productDto.Clients.Distinct())
                {
                    if(!existingClients.Contains(clientId))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }
                    ProductClient productClient = new ProductClient()
                    {
                        Product = product,
                        ClientId = clientId
                    };
                   product.ProductsClients.Add(productClient);
                }
                mappedProducts.Add(product);
                sb.AppendLine(string.Format(SuccessfullyImportedProducts, product.Name, product.ProductsClients.Count()));
            }
         
            context.Products.AddRange(mappedProducts);
            context.SaveChanges();
            return sb.ToString().TrimEnd();

        }

        public static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    } 
}
