﻿





namespace Invoices.DataProcessor.ImportDto
{
    using System.ComponentModel.DataAnnotations;
    using System.Xml.Serialization;

    using Commun;

    [XmlType("Client")]
    public  class ImportClientDTO
    {
        //    <Name>LiCB</Name>
        //<NumberVat>BG5464156654654654</NumberVat>
        [XmlElement("Name")]
        [Required]
        [MinLength(ValidationConstants.MinLeghtClientName)]
        [MaxLength(ValidationConstants.MaxLenghtClientName)]
        public string Name { get; set; }


        [XmlElement("NumberVat")]
        [Required]
        [MinLength(ValidationConstants.MinLenghtNumberVat)]
        [MaxLength(ValidationConstants.MaxLenghtNumberVat)]
        public string NumberVat { get; set; }

        [XmlArray("Addresses")]
        public ImportDtoAddress[] Addresses { get; set; }
       
       

    }
}
