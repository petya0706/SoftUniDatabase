﻿namespace Invoices.DataProcessor.ImportDto
{
    
    using System.ComponentModel.DataAnnotations;
    using System.Xml.Serialization;

    using Commun;


    [XmlType("Address")]
    public  class ImportDtoAddress
    {
        //{/*<*/Address>
        //    <StreetName>Gnigler strasse</StreetName>
        //    <StreetNumber>57</StreetNumber>
        //    <PostCode>5020</PostCode>
        //    <City>Salzburg</City>
        //    <Country>Austria</Country>
        //  </Address>
       [XmlElement("StreetName")]
       [Required]
       [MinLength(ValidationConstants.MinLenghtAddress)]
       [MaxLength(ValidationConstants.MaxLenghtAddress)]
       public string StreetName  { get; set; }


        [XmlElement("StreetNumber")]
       public int StreetNumber { get; set; }

        [XmlElement("PostCode")]
        [Required]
        public string  PostCode { get; set; }

        [XmlElement("City")]
        [Required]
        [MinLength(ValidationConstants.MinLenghtCity)]
        [MaxLength(ValidationConstants.MaxLenghtCity)]
        public string City { get; set; }

        [XmlElement("Country")]
        [Required]
        [MinLength(ValidationConstants.MinLenghtCountry)]
        [MaxLength (ValidationConstants.MaxLenghtCountry)] 
        public string Country { get; set; }

    }
}
