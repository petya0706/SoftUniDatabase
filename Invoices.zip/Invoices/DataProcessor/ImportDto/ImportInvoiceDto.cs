﻿namespace Invoices.DataProcessor.ImportDto
{

    using Newtonsoft.Json;
    using System.ComponentModel.DataAnnotations;

    using Commun;
    public  class ImportInvoiceDto
    {
        //        {
        //  "Number": 1427940691,
        //  "IssueDate": "2022-08-29T00:00:00",
        //  "DueDate": "2022-10-28T00:00:00",
        //  "Amount": 913.13,
        //  "CurrencyType": 1,
        //  "ClientId": 1
        //},
        [JsonProperty]
        [Range(ValidationConstants.MinNumberInvoice,ValidationConstants.MaxNumberInvoice)]
        public int Number { get; set; }

        [JsonProperty]
        [Required]
        public string IssueDate { get; set; }

        [JsonProperty]
        [Required]
        public string Duedate { get; set; }

        [JsonProperty]
        public decimal Amount { get; set; }

        [JsonProperty]
        [Range(ValidationConstants.MinCurrencyType,ValidationConstants.MaxCurrencyType)]
        public int CurrencyType { get; set; }

        [JsonProperty]
        public int ClientId { get ; set; }  



    }
}
