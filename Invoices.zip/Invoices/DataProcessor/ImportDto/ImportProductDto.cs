﻿namespace Invoices.DataProcessor.ImportDto
{
    using System.ComponentModel.DataAnnotations;

    using Commun;
    using Newtonsoft.Json;

    public  class ImportProductDto
    {
        //      [
        //{
        //  "Name": "ADR plate",
        //  "Price": 14.97,
        //  "CategoryType": 1,
        //  "Clients": [
        //    1,
        //    105,
        //    1,
        //    5,
        //    15
        //  ]
        //  },
        [JsonProperty]
        [Required]
        [MinLength(ValidationConstants.MinLenghProductName)]
        [MaxLength(ValidationConstants.MaxProductLenghtName)]
        public string Name { get; set; }

        [JsonProperty]
        [Range(typeof(decimal),ValidationConstants.MinPrice ,ValidationConstants.MaxPrice)]
        public decimal Price { get; set; }

        [JsonProperty]
        [Range(ValidationConstants.MinCategoryType,ValidationConstants.MaxCategoryType)]
        public int CategoryType { get; set; }

        [JsonProperty]
        public int[] Clients { get; set; }  


    }
}
