﻿namespace Invoices.DataProcessor
{
    using AutoMapper;
    using AutoMapper.QueryableExtensions;
    using Invoices.Data;
    using Invoices.DataProcessor.ExportDto;
    using Invoices.Utilities;
    using Microsoft.EntityFrameworkCore;
    using Newtonsoft.Json;
    using System.Globalization;

    public class Serializer
    {
        public static string ExportClientsWithTheirInvoices(InvoicesContext context, DateTime date)
        {
            MapperConfig config = new MapperConfig();
            IMapper mapper = config.ConfigurationMapper();
            var clientsToexport = context.Clients.
                 Where(c => c.Invoices.Any(i => i.IssueDate > date)).OrderByDescending(c => c.Invoices.Count()).
                 ThenBy(c => c.Name).AsNoTracking().
                 ProjectTo<ClientExportDto>(mapper.ConfigurationProvider).ToArray();
                
                
             XmlHelper xmlHelper = new XmlHelper();
            var result = xmlHelper.Serialize<ClientExportDto[]>(clientsToexport, "Clients");
            return result;
        }

        public static string ExportProductsWithMostClients(InvoicesContext context, int nameLength)
        {

            var productsExport = context.
                Products.Where(p => p.ProductsClients.Any(c => c.Client.Name.Length >= nameLength)).
                ToArray().Select(p => new
                {
                    p.Name,
                    p.Price,
                    Category = p.CategoryType.ToString(),
                    Clients = p.ProductsClients.Where(c => c.Client.Name.Length >= nameLength).
                    OrderBy(c => c.Client.Name).Select(c => new
                    {
                        Name = c.Client.Name,
                        NumberVat = c.Client.NumberVat
                    }).ToArray()
                }).OrderByDescending(p => p.Clients.Count()).ThenBy(p => p.Name).Take(5).ToArray();
            var result = JsonConvert.SerializeObject(productsExport , new JsonSerializerSettings()
            {
                Formatting = Formatting.Indented,
                NullValueHandling = NullValueHandling.Ignore,
            });
            return result;
        }
    }
}