﻿using AutoMapper;

namespace Invoices
{
    using Data.Models;
    using DataProcessor.ImportDto;
    using Invoices.Data.Models.Enums;
    using Invoices.DataProcessor.ExportDto;
    using System.Globalization;

    public class InvoicesProfile : Profile
    {
        public InvoicesProfile()
        {
            this.CreateMap<ImportDtoAddress, Address>();

            this.CreateMap<ImportInvoiceDto, Invoice>().
                ForMember(s => s.IssueDate, opt =>
                opt.MapFrom(d => DateTime.Parse(d.IssueDate, CultureInfo.InvariantCulture, DateTimeStyles.None))).
                ForMember(s => s.DueDate,
                opt => opt.MapFrom(d => DateTime.Parse(d.Duedate, CultureInfo.InvariantCulture, DateTimeStyles.None))).
                ForMember(s => s.CurrencyType, opt => opt.MapFrom(d => (CurrencyType)d.CurrencyType));

            this.CreateMap<Invoice, InvoiceExportDto>().
                ForMember(s => s.InvoiceNumber, opt => opt.MapFrom(d => d.Number)).
                ForMember(s => s.InvoiceAmount, opt => opt.MapFrom(d => d.Amount)).
                ForMember(s => s.DueDate, opt => opt.MapFrom(d => d.DueDate.ToString("d", CultureInfo.InvariantCulture))).
                ForMember(s => s.Currency, opt => opt.MapFrom(d => d.CurrencyType.ToString()));

            this.CreateMap<Client, ClientExportDto>().
                ForMember(s => s.InvoicesCount, opt => opt.MapFrom(d => d.Invoices.Count())).
                ForMember(s => s.Name, opt => opt.MapFrom(d => d.Name)).
                ForMember(s => s.VatNumber, opt => opt.MapFrom(d => d.NumberVat)).
                ForMember(s => s.Invoices, opt => opt.MapFrom(d => d.Invoices.OrderBy(i => i.IssueDate).ThenByDescending(i => i.DueDate)));


        }
    }
}
