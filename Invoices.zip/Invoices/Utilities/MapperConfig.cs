﻿
namespace Invoices.Utilities
{
    using AutoMapper;
    public class MapperConfig
    {
        

            public IMapper ConfigurationMapper()
            {
                IMapper mapper =
                    new Mapper(new MapperConfiguration(cf =>
                    {
                        cf.AddProfile<InvoicesProfile>();
                    }));
                return mapper;
            }

        
    }
}
