﻿

using System.Text;
using System.Xml.Serialization;

namespace Invoices.Utilities
{
    public  class XmlHelper
    {
        public T Deserialize<T>(string inputXml, string rootName)
        {
            XmlRootAttribute root = new XmlRootAttribute(rootName);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), root);
            StringReader reader = new StringReader(inputXml);
            T supplierDTOs =
            (T)xmlSerializer.Deserialize(reader);

            return supplierDTOs;
        }

        public IEnumerable<T> DeserializeCollection<T>(string inputXml, string rootName)
        {
            XmlRootAttribute root = new XmlRootAttribute(rootName);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T[]), root);
            StreamReader reader = new StreamReader(inputXml);
            T[] supplierDTOs =
            (T[])xmlSerializer.Deserialize(reader);

            return supplierDTOs;
        }

        public string Serialize<T>(T obj, string rootName)
        {
            XmlRootAttribute root = new XmlRootAttribute(rootName);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), root);
            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);
            StringBuilder sb = new StringBuilder();
            StringWriter sw = new StringWriter(sb);
            xmlSerializer.Serialize(sw, obj, namespaces);


            return sb.ToString().TrimEnd();
        }

        public string SerializeCollection<T>(T[] obj, string rootName)
        {
            XmlRootAttribute root = new XmlRootAttribute(rootName);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T[]), root);
            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);
            StringBuilder sb = new StringBuilder();
            StringWriter sw = new StringWriter(sb);
            xmlSerializer.Serialize(sw, obj, namespaces);


            return sb.ToString().TrimEnd();
        }

    }
}
